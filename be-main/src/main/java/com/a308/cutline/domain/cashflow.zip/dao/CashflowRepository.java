// src/main/java/com/a308/cutline/domain/cashflow/dao/CashflowRepository.java
package com.a308.cutline.domain.cashflow.dao;

import com.a308.cutline.domain.cashflow.entity.Cashflow;
import com.a308.cutline.common.entity.Person;
import com.a308.cutline.domain.cashflow.entity.Direction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.List;

public interface CashflowRepository extends JpaRepository<Cashflow, Long> {

    // 전체 히스토리(미삭제만), date DESC, id DESC
    List<Cashflow> findAllByPersonAndDeletedAtIsNullOrderByDateDescIdDesc(Person person);

    Optional<Cashflow>
    findTopByPerson_IdAndCategory_IdAndDirectionAndChangedPriceIsNotNullAndDeletedAtIsNullOrderByDateDescIdDesc(
            Long personId, Long categoryId, Direction direction
    );
    

}
